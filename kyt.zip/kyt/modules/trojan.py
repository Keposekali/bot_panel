from kyt import *

#delete
@bot.on(events.CallbackQuery(data=b'delete7-trojan'))
async def delete_trojan(event):
	async def delete_trojan_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/config.json | grep '^#trg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.respond(f"""
**⚡ LIST DELETE USER**
{z}
**👉 Select Your Number :**
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "4" "{user}" | m-trojan | sleep 3 | exit'
		subprocess.check_output(cmd, shell=True)
		await event.respond(f"""
**» SUCCES**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#renew
@bot.on(events.CallbackQuery(data=b'renew7-trojan'))
async def renew_trojan(event):
	async def renew_trojan_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/config.json | grep '^#trg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.respond(f"""
**⚡ LIST RENEW USER**
{z}
**👉 Select Your Number :**
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**» Expired (Hari) :**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		cmd = f'printf "%s\n" "3" "{user}" "{exp}" | m-trojan | sleep 3 | exit'
		subprocess.check_output(cmd, shell=True)
		await event.respond(f"""
**» SUCCES**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await renew_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#restore
@bot.on(events.CallbackQuery(data=b'limit7-trojan'))
async def limit_trojan(event):
	async def limit_trojan_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/config.json | grep '^#trg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.respond(f"""
**⚡ CHANGE LIMIT USER**
{z}
**👉 Select Your Number :**
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**» Limit User (IP) or 0 Unlimited :**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**» Limit User (GB) or 0 Unlimited :**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		cmd = f'printf "%s\n" "7" "{user}" "{exp}" "{pw}" | m-trojan | sleep 3 | exit'
		subprocess.check_output(cmd, shell=True)
		await event.respond(f"""
**» SUCCES CHANGE**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await limit_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#MultiLogin
@bot.on(events.CallbackQuery(data=b'login7-trojan'))
async def login_trojan(event):
	async def login_trojan_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/trojan/listlock | grep '^###' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.respond(f"""
**⚡ LIST MULTI LOGIN USER**
{z}
**👉 Select Your Number :**
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "9" "{user}" | m-trojan | sleep 3 | exit'
		subprocess.check_output(cmd, shell=True)
		await event.respond(f"""
**» SUCCES UNLOCK**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await login_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#CRATE trojan
@bot.on(events.CallbackQuery(data=b'create7-trojan'))
async def create_trojan(event):
	async def create_trojan_(event):
		async with bot.conversation(chat) as user:
			await event.respond(f"""
**⚠️ No Spasi**
**⚠️ No Double Name**

**👉 Input Your UserName :**
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**» Expired (Hari) :**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**» Limit User (IP) or 0 Unlimited :**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as pw2:
			await event.respond("**» Limit User (GB) or 0 Unlimited :**")
			pw2 = pw2.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw2 = (await pw2).raw_text
		cmd = f'printf "%s\n" "1" "{user}" "{exp}" "{pw}" "{pw2}" | m-trojan | sleep 3 | exit'
		subprocess.check_output(cmd, shell=True)
		await event.respond(f"""
**» SUCCES CREATE**
**» DONE**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

# TRIAL trojan
@bot.on(events.CallbackQuery(data=b'trial7-trojan'))
async def trial_trojan(event):
	async def trial_trojan_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Expired (Minutes) :**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		cmd = f'printf "%s\n" {2} "{exp}" | m-trojan | sleep 3 | exit'
		subprocess.check_output(cmd, shell=True)
		await event.respond(f"""
**» SUCCES CREATE**
**» DONE**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#CEK
@bot.on(events.CallbackQuery(data=b'cek7-trojan'))
async def cek_trojan(event):
	async def cek_trojan_(event):
		cmd = 'bot-cek-tr'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**⚠️ TROJAN USER ONLINE**
{z}
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_trojan_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'trojan'))
async def trojan(event):
	async def trojan_(event):
		inline = [
[Button.inline(" Trial ","trial7-trojan"),
Button.inline(" Create ","create7-trojan"),
Button.inline(" Login ","cek7-trojan")],
[Button.inline(" Delete ","delete7-trojan"),
Button.inline(" Unlock ","login7-trojan"),
Button.inline(" Limit ","limit7-trojan")],
[Button.inline(" Renew","renew7-trojan"),
Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🪯 MENU TROJAN**
━━━━━━━━━━━━━━━━━━━━━━━ 
🔱 **» Service:** `TROJAN`
🔱 **» Hostname/IP:** `{DOMAIN}`
🔱 **» ISP:** `{z["isp"]}`
🔱 **» Country:** `{z["country"]}`
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trojan_(event)
	else:
		await event.answer("Access Denied",alert=True)
